// UMT Portal Auto Captcha - popup.js v3.0
// Made by: 5 Star Dairy Farm

const studentIdEl = document.getElementById('studentId');
const passwordEl  = document.getElementById('password');
const submitBtn   = document.getElementById('submitBtn');
const statusEl    = document.getElementById('status');
const autoToggle  = document.getElementById('autoToggle');
const savedNotice = document.getElementById('savedNotice');
const clearLink   = document.getElementById('clearLink');
const eyeBtn      = document.getElementById('eyeBtn');
const eyeIcon     = document.getElementById('eyeIcon');

// ─── Show status ──────────────────────────────────────────────────────────────
function showStatus(msg, type, duration = 4000) {
  statusEl.textContent = msg;
  statusEl.className = type;
  statusEl.style.display = 'block';
  if (duration) setTimeout(() => { statusEl.style.display = 'none'; }, duration);
}

// ─── Eye toggle ───────────────────────────────────────────────────────────────
let passVisible = false;
eyeBtn.addEventListener('click', () => {
  passVisible = !passVisible;
  passwordEl.type = passVisible ? 'text' : 'password';
  eyeIcon.innerHTML = passVisible
    ? '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>'
    : '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
});

// ─── Load saved credentials on popup open ────────────────────────────────────
chrome.storage.local.get(['umtId', 'umtPass', 'autoSolve'], (data) => {
  if (data.umtId) {
    studentIdEl.value = data.umtId;
    passwordEl.value  = data.umtPass || '';
    savedNotice.classList.add('show');
    clearLink.style.display = 'block';
    submitBtn.textContent = 'UPDATE';
  }
  autoToggle.checked = data.autoSolve !== false;
});

// ─── Submit: save credentials & trigger fill ─────────────────────────────────
submitBtn.addEventListener('click', async () => {
  const id   = studentIdEl.value.trim();
  const pass = passwordEl.value;

  if (!id || !pass) {
    showStatus('⚠️ Please enter your Student ID and Password.', 'error');
    return;
  }

  // Save to local storage
  chrome.storage.local.set({ umtId: id, umtPass: pass }, () => {
    showStatus('✅ Credentials saved! Opening UMT portal...', 'success');
    savedNotice.classList.add('show');
    clearLink.style.display = 'block';
    submitBtn.textContent = 'UPDATE';

    // Open the portal and fill everything
    setTimeout(() => {
      chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
        const isPortal = tab?.url?.includes('umt.edu.pk');

        if (isPortal) {
          // Already on portal — inject and fill
          injectAndFill(tab.id, id, pass);
        } else {
          // Open portal tab
          chrome.tabs.create({ url: 'https://online.umt.edu.pk/Account/Login' }, (newTab) => {
            // Wait for page to load, then fill
            chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
              if (tabId === newTab.id && info.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(listener);
                setTimeout(() => injectAndFill(newTab.id, id, pass), 1000);
              }
            });
          });
        }
      });
    }, 600);
  });
});

// ─── Inject content script & send fill command ───────────────────────────────
function injectAndFill(tabId, id, pass) {
  chrome.scripting.executeScript(
    { target: { tabId }, files: ['content.js'] },
    () => {
      setTimeout(() => {
        chrome.tabs.sendMessage(tabId, {
          action: 'fillAll',
          studentId: id,
          password: pass,
        }, (response) => {
          if (chrome.runtime.lastError) return;
          if (response?.success) {
            showStatus('✅ ' + response.message, 'success');
          }
        });
      }, 400);
    }
  );
}

// ─── Clear credentials ────────────────────────────────────────────────────────
clearLink.addEventListener('click', () => {
  if (!confirm('Clear saved credentials?')) return;
  chrome.storage.local.remove(['umtId', 'umtPass'], () => {
    studentIdEl.value = '';
    passwordEl.value  = '';
    savedNotice.classList.remove('show');
    clearLink.style.display = 'none';
    submitBtn.textContent = 'SUBMIT';
    showStatus('🗑️ Credentials cleared.', 'info');
  });
});

// ─── Auto-toggle ─────────────────────────────────────────────────────────────
autoToggle.addEventListener('change', () => {
  chrome.storage.local.set({ autoSolve: autoToggle.checked });
});