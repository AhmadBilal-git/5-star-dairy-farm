// UMT Portal Auto Captcha - content.js v3.0
// Made by: 5 Star Dairy Farm
// Fills: Student ID + Password + CAPTCHA automatically

(function () {
  'use strict';

  const CAPTCHA_PATTERN = /^[a-zA-Z0-9]{3,10}$/;

  function log(msg) { console.log('[UMT Auto Captcha] ' + msg); }

  // ─── Fill input (works with React/Angular/plain JS) ──────────────────────────
  function fillInput(el, value) {
    if (!el) return false;
    el.focus();
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
    return true;
  }

  // ─── Find Student ID input ───────────────────────────────────────────────────
  function findIdInput() {
    const selectors = [
      'input[name="UserName"]',
      'input[name="username"]',
      'input[name="StudentId"]',
      'input[name="studentId"]',
      'input[name="Email"]',
      'input[name="email"]',
      'input[id="UserName"]',
      'input[id="username"]',
      'input[placeholder*="Student ID" i]',
      'input[placeholder*="Email" i]',
      'input[placeholder*="User" i]',
      'input[type="email"]',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) { log(`ID field: ${sel}`); return el; }
    }
    // Fallback: first text input
    return document.querySelector('input[type="text"]');
  }

  // ─── Find Password input ─────────────────────────────────────────────────────
  function findPasswordInput() {
    const el = document.querySelector(
      'input[type="password"], input[name="Password"], input[name="password"], input[id="Password"], input[id="password"]'
    );
    if (el) { log('Password field found'); return el; }
    return null;
  }

  // ─── Find CAPTCHA text on page ───────────────────────────────────────────────
  function findCaptchaText() {
    // Explicit captcha selectors first
    const explicitSelectors = [
      '[id*="captcha" i]',
      '[class*="captcha" i]',
      '[id*="CaptchaCode" i]',
      '[id*="verif" i]',
      '.captcha', '#captcha', '#CaptchaCode',
    ];
    for (const sel of explicitSelectors) {
      try {
        const el = document.querySelector(sel);
        if (el && el.tagName !== 'INPUT') {
          const t = (el.innerText || el.textContent || '').trim();
          if (t && CAPTCHA_PATTERN.test(t)) { log(`Captcha via "${sel}": ${t}`); return t; }
        }
      } catch (_) {}
    }

    // Scan all short-text visible elements
    const tags = document.querySelectorAll('div,span,td,p,label,strong,b,em,li,h1,h2,h3,h4,h5,h6');
    const candidates = [];

    for (const el of tags) {
      if (['INPUT','TEXTAREA','SELECT','SCRIPT','STYLE','A','BUTTON'].includes(el.tagName)) continue;
      const directText = getDirectText(el);
      if (!directText || !CAPTCHA_PATTERN.test(directText)) continue;

      let score = 0;
      const style = window.getComputedStyle(el);
      const fontSize = parseFloat(style.fontSize) || 14;
      const id  = (el.id || '').toLowerCase();
      const cls = (el.className || '').toLowerCase();

      if (id.includes('captcha') || cls.includes('captcha')) score += 100;
      if (id.includes('code')    || cls.includes('code'))    score += 50;
      if (fontSize >= 18) score += 30;
      if (fontSize >= 14) score += 10;
      if (/[0-9]/.test(directText)) score += 10;
      if (/[a-z]/.test(directText) && /[A-Z]/.test(directText)) score += 10;

      candidates.push({ text: directText, score });
    }

    if (candidates.length > 0) {
      candidates.sort((a, b) => b.score - a.score);
      log(`Captcha text: "${candidates[0].text}" (score ${candidates[0].score})`);
      return candidates[0].text;
    }
    return null;
  }

  function getDirectText(el) {
    let t = '';
    for (const node of el.childNodes) {
      if (node.nodeType === Node.TEXT_NODE) t += node.textContent;
    }
    return t.trim();
  }

  // ─── Find CAPTCHA input field ────────────────────────────────────────────────
  function findCaptchaInput() {
    const selectors = [
      'input[placeholder="Code"]',
      'input[name="CaptchaInputText"]',
      'input[name="captchaCode"]',
      'input[name="CaptchaCode"]',
      'input[id="CaptchaInputText"]',
      'input[id="captchaCode"]',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) { log(`Captcha input: ${sel}`); return el; }
    }
    // Broader scan
    const allInputs = document.querySelectorAll('input[type="text"], input:not([type])');
    for (const inp of allInputs) {
      const ph   = (inp.placeholder || '').toLowerCase();
      const name = (inp.name || '').toLowerCase();
      const id   = (inp.id || '').toLowerCase();
      if (ph.includes('code') || ph.includes('captcha') ||
          name.includes('code') || name.includes('captcha') ||
          id.includes('code') || id.includes('captcha')) {
        log(`Captcha input (broad): ${inp.name || inp.id}`);
        return inp;
      }
    }
    // Last resort: last text input
    const inputs = Array.from(document.querySelectorAll('input[type="text"],input:not([type])'));
    const filtered = inputs.filter(i => {
      const n = (i.name || '').toLowerCase();
      return !n.includes('user') && !n.includes('email') && !n.includes('pass');
    });
    return filtered.length > 0 ? filtered[filtered.length - 1] : null;
  }

  // ─── Status badge on page ─────────────────────────────────────────────────────
  function showBadge(message, type) {
    let badge = document.getElementById('_umt_badge');
    if (!badge) {
      badge = document.createElement('div');
      badge.id = '_umt_badge';
      Object.assign(badge.style, {
        position: 'fixed', bottom: '18px', right: '18px', zIndex: '2147483647',
        padding: '10px 16px', borderRadius: '12px', fontFamily: 'Segoe UI,Arial,sans-serif',
        fontSize: '13px', fontWeight: 'bold', boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
        transition: 'opacity 0.4s', maxWidth: '290px', lineHeight: '1.5',
      });
      document.body.appendChild(badge);
    }
    const themes = {
      success: { bg: '#1a5c36', border: '#2d9959', color: '#fff' },
      error:   { bg: '#5c1a1a', border: '#995050', color: '#fff' },
      info:    { bg: '#1a3a8c', border: '#4a70d0', color: '#fff' },
    };
    const t = themes[type] || themes.info;
    Object.assign(badge.style, { background: t.bg, border: `1px solid ${t.border}`, color: t.color, opacity: '1' });
    badge.innerHTML = `🎓 UMT Auto Captcha<br><span style="font-weight:normal;font-size:12px;">${message}</span>`;
    clearTimeout(badge._hide);
    badge._hide = setTimeout(() => { badge.style.opacity = '0'; setTimeout(() => badge.remove(), 400); }, 5000);
  }

  // ─── MAIN: fill everything ────────────────────────────────────────────────────
  function fillAll(studentId, password) {
    let filled = [];

    // 1. Fill Student ID
    if (studentId) {
      const idEl = findIdInput();
      if (idEl && fillInput(idEl, studentId)) filled.push('Student ID');
    }

    // 2. Fill Password
    if (password) {
      const passEl = findPasswordInput();
      if (passEl && fillInput(passEl, password)) filled.push('Password');
    }

    // 3. Fill Captcha
    const captchaText = findCaptchaText();
    if (captchaText) {
      const captchaInput = findCaptchaInput();
      if (captchaInput && fillInput(captchaInput, captchaText)) filled.push(`Captcha "${captchaText}"`);
    }

    if (filled.length > 0) {
      const msg = '✓ Auto-filled: ' + filled.join(', ');
      showBadge(msg, 'success');
      log(msg);
      return { success: true, message: msg };
    } else {
      showBadge('Could not find form fields on this page.', 'error');
      return { success: false, message: 'Could not find form fields.' };
    }
  }

  // ─── Listen for popup messages ────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'fillAll') {
      const result = fillAll(request.studentId, request.password);
      sendResponse(result);
    }
    if (request.action === 'solveCaptcha') {
      // Captcha only (manual trigger, no saved creds)
      const captchaText = findCaptchaText();
      if (!captchaText) {
        sendResponse({ success: false, message: 'Captcha not found.' });
        return;
      }
      const captchaInput = findCaptchaInput();
      if (captchaInput && fillInput(captchaInput, captchaText)) {
        showBadge(`✓ Captcha filled: "${captchaText}"`, 'success');
        sendResponse({ success: true, message: `Filled: "${captchaText}"` });
      } else {
        sendResponse({ success: false, message: 'Captcha input not found.' });
      }
    }
    return true;
  });

  // ─── Auto-fill on page load ───────────────────────────────────────────────────
  function autoFillOnLoad() {
    chrome.storage.local.get(['umtId', 'umtPass', 'autoSolve'], (data) => {
      if (data.autoSolve === false) return;

      const doFill = () => fillAll(data.umtId || null, data.umtPass || null);

      if (document.readyState === 'complete') {
        setTimeout(doFill, 900);
      } else {
        window.addEventListener('load', () => setTimeout(doFill, 900));
      }
    });
  }

  autoFillOnLoad();
  log('Loaded on: ' + window.location.href);
})();